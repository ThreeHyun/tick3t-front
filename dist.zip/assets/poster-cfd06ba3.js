const s="/assets/poster-d6d7d22f.jpg";export{s as _};
