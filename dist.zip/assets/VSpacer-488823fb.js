import{c as a}from"./VAvatar-977cf983.js";const e=a("v-spacer","div","VSpacer");export{e as V};
