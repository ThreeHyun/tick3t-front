const s="/assets/logo-5e6edada.png";export{s as _};
